create database data;
use data;
-- create table Users(Username varchar(20), Password varchar(20));
select * from Users;